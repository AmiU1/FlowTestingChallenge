package executionEngine;


import java.lang.reflect.Method;
import org.apache.log4j.xml.DOMConfigurator;
import appFunctions.AppFunctions;
import appFunctions.Constants;
import utility.ExcelUtils;
import utility.Log;
import utility.Reports;


//import org.testng.annotations.*;
//import org.testng.annotations.Parameters;
 
public class DriverScript {

	//public static Properties OR;
	public static AppFunctions appFunctions;
	public static String sAppFunctions;
	public static String sPageObject;
	public static String sByProperty;
	public static Method method[];
	public static int iTestStep;
	public static int iTestLastStep;
	public static String sTestCaseID;
	public static String sRunMode;
	//public static String sData;
	public static boolean bResult;
	public static String sTestCaseName;
	public static String sExecutionMarker;
	public static String sTestStep;
	public static int iTestData;
	public static int iTestLastData;
	public static String sVarName;
	
	public DriverScript() throws NoSuchMethodException, SecurityException{
		appFunctions = new AppFunctions();
		method = appFunctions.getClass().getMethods();	
	}
//	 @Test
	public static void main(String[] args) throws Exception 
	//public static void A() throws Exception 
    {
    	
    		DOMConfigurator.configure("log4j.xml");
			ExcelUtils.setExcelFile(Constants.Path_TestExecutionSheet);
			DriverScript startEngine = new DriverScript();
			startEngine.execute_TestCase();
		
			
   }

    public void execute_TestCase() throws Exception 
    {
    	
	    	int iTotalTestCases = ExcelUtils.getRowCount(Constants.Sheet_TestCases);
			for(int iTestcase=1;iTestcase<iTotalTestCases;iTestcase++)
		
			{
    	
				bResult = true;
				sTestCaseID = ExcelUtils.getCellData(iTestcase, Constants.Col_TestCaseID, Constants.Sheet_TestCases); 
				sRunMode = ExcelUtils.getCellData(iTestcase, Constants.Col_RunMode,Constants.Sheet_TestCases);
				sTestCaseName = ExcelUtils.getCellData(iTestcase, Constants.Col_TestDescription,Constants.Sheet_TestCases);
				if (sRunMode.equals("Yes"))
				
				{
					Log.startTestCase(sTestCaseID);
					Reports.startExtentReport(sTestCaseName);
					iTestStep = ExcelUtils.getRowContains(sTestCaseID, Constants.Col_TestCaseID, Constants.Sheet_TestSteps);
					iTestLastStep = ExcelUtils.getTestStepsCount(Constants.Sheet_TestSteps, sTestCaseID, iTestStep);
					bResult=true;
					for (;iTestStep<iTestLastStep;iTestStep++)
				
					{
						sExecutionMarker = ExcelUtils.getCellData(iTestStep, Constants.Col_TestStepExecutionMarker,Constants.Sheet_TestSteps);
						if(!sExecutionMarker.equalsIgnoreCase("#"))
						{
						sAppFunctions = ExcelUtils.getCellData(iTestStep, Constants.Col_ActionKeyword,Constants.Sheet_TestSteps);
			    		sPageObject = ExcelUtils.getCellData(iTestStep, Constants.Col_PageObject, Constants.Sheet_TestSteps);			    		
			    		sVarName = ExcelUtils.getCellData(iTestStep, Constants.Col_DataSet, Constants.Sheet_TestSteps);
			    		sByProperty = ExcelUtils.getCellData(iTestStep, Constants.Col_ByProperty, Constants.Sheet_TestSteps);
			    		sTestStep = ExcelUtils.getCellData(iTestStep, Constants.Col_TestStepDescription, Constants.Sheet_TestSteps);
			    		execute_Actions();
						}
					
						if(!sExecutionMarker.equalsIgnoreCase("#")) 
						{
			    		if (bResult==true)
			    		{
			    			//Reports.ReportPass("Action: " + sAppFunctions + " || "+ " PageObject: "+ sPageObject + " || " + " Data: " + sData + " || " + " By Property: " + sByProperty +"   "+ "==><B> PASSED");
			    			Reports.ReportPass("Test Step: " + "<B>"+sTestStep);
			    		}
						}
			    		
						if(bResult==false)
						{
							ExcelUtils.setCellData(Constants.KEYWORD_FAIL,iTestcase,Constants.Col_Result,Constants.Sheet_TestCases);
							//Reports.ReportFail("Action: " + sAppFunctions + " || "+ " PageObject: "+ sPageObject + " || " + " Data: " + sData + " || " + " By Property: " + sByProperty +"   "+"==> <B>FAILED");
							Reports.ReportFail("Test Step: " +"<B>"+sTestStep);
						//	Reports.ReportInfo("Adding Screenshot", ActionKeywords.CaptureScreen());
							Log.endTestCase(sTestCaseID);
							Reports.EndReport();
							Reports.FlushReport();
							break;
							}						
						}
					if(bResult==true)
					{
					ExcelUtils.setCellData(Constants.KEYWORD_PASS,iTestcase,Constants.Col_Result,Constants.Sheet_TestCases);
					Log.endTestCase(sTestCaseID);
					Reports.EndReport();
					Reports.FlushReport();
										
					}
				}}}
			
     public static void execute_Actions() throws Exception 
     {
	
		for(int i=0;i<method.length;i++)
		{
			
			if(method[i].getName().equals(sAppFunctions))
			{
				method[i].invoke(appFunctions,sPageObject,sVarName,sByProperty);
				if(bResult==true)
				{
					ExcelUtils.setCellData(Constants.KEYWORD_PASS, iTestStep, Constants.Col_TestStepResult, Constants.Sheet_TestSteps);
					break;
				}
				else
				{
					ExcelUtils.setCellData(Constants.KEYWORD_FAIL, iTestStep, Constants.Col_TestStepResult, Constants.Sheet_TestSteps);
					
					break;
					}
				}
				
    }
		
		}
   
     }
     
















