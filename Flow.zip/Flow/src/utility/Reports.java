	package utility;
 

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import appFunctions.AppFunctions;
//import config.Constants;
 
 
public class Reports { 
      static ExtentReports extent = new ExtentReports(AppFunctions.GetReportPath(null, null, null), true);
      static ExtentTest test;
     
      public static void startExtentReport(String sTestCaseName){
            test = extent.startTest(sTestCaseName);
               }
     
      public static void ReportInfo(String message, String imagePath){
            test.log(LogStatus.INFO, message, test.addScreenCapture(imagePath));
               }
     
      public static void ReportPass(String message) {
            test.log(LogStatus.PASS, message);
               }
     
      public static void ReportFail(String message) {
    	  test.log(LogStatus.FAIL, message);
               }
     
      public static void EndReport() {
            extent.endTest(test);
               }
     
      public static void FlushReport(){
            extent.flush();
      }
      
     
}