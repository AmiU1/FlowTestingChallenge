package appFunctions;

public class Constants {
	
	//System Variables
	//public static final String URL = "http://nidlamsdemo.cloudapp.net/Customer/";
	public static final String Path_TestExecutionSheet = "C:\\BTA\\Hybrid Keyword Driven\\src\\dataEngine\\ExecutionEngine.xlsx";
	//public static final String Path_OR = "C:\\\\Automation\\\\Hybrid Keyword Driven\\\\src\\\\config\\\\OR.txt";
	public static final String Path_OR = "C:\\BTA\\Hybrid Keyword Driven\\src\\dataEngine\\OR.xlsx";
	public static final String Path_TestDataSheet = "C:\\BTA\\Hybrid Keyword Driven\\src\\dataEngine\\DataEngine.xlsx";
	public static final String Path_TestReport = "C:\\\\Automation\\\\Reports\\\\AutomationReport.html";
	public static final String Path_TestScreenshots = "C:\\\\Automation\\\\Reports\\\\Screenshots";	//****put folder path for Screenshot****
	public static final String File_TestData = "DataEngine.xlsx";
	public static final String KEYWORD_FAIL = "FAIL";
	public static final String KEYWORD_PASS = "PASS";
	
	//Data Sheet Column Numbers
	public static final int Col_TestCaseID = 0;	
	public static final int Col_TestScenarioID =1 ;
	public static final int Col_TestDescription =1 ;
	public static final int Col_PageObject =4 ;
	public static final int Col_ActionKeyword =5 ;
	public static final int Col_RunMode =2 ;
	public static final int Col_Result =3 ;
	public static final int Col_DataSet =7 ;
	public static final int Col_TestStepResult =8 ;
	public static final int Col_ByProperty =6 ;
	public static final int Col_TestStepExecutionMarker=9;
	public static final int Col_TestStepDescription =2 ;
	public static final int Col_DataVariableName =1 ;
	public static final int Col_DataVariableValue =2 ;
	public static final int row1 =1;
			public static final int col1 =2;
			public static final int col11 =8;
		
	// Data Engine Excel sheets
	public static final String Sheet_TestSteps = "Test Steps";
	public static final String Sheet_TestCases = "Test Cases";
	public static final String Sheet_TestData = "Test Data";
	
	//OR Sheet
	public static final String Sheet_OR = "Object Repository";
	
	
	

	// Global Variable
	public static String TempGlobal1 = "";
	public static String TempGlobal2 = "";
	public static String TempEmail = "";
	public static String TempPIN = "" ;
	public static String TempMessage="";
	public static String duration="";;
	public static String distance="";
	public static String score="";
	public static String score1="";
	public static String Jdate="";
	public static String Jtime="";
	public static String Jdistance="";
	public static String Jduration="";
	
}
