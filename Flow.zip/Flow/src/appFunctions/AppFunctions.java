package appFunctions;

import java.io.FileInputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import appFunctions.Constants;
import executionEngine.DriverScript;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;
import utility.Log;

public class AppFunctions


{
	public static AndroidDriver<MobileElement> driver1;
	public static WebDriver driver;
	 
	 
	 
	 
	  public static String GetObjectProperty(String object){
		  final XSSFSheet ORWSheet;
	      final XSSFWorkbook ORWBook;
	      org.apache.poi.ss.usermodel.Cell Cell;
	     
		  try {
	          FileInputStream ExcelFile = new FileInputStream(Constants.Path_OR);
	          ORWBook = new XSSFWorkbook(ExcelFile);
	          ORWSheet = ORWBook.getSheet(Constants.Sheet_OR);
	          Log.info("The object is: "+object);
	          //Get RowCount
	          int ORRowCount = ORWSheet.getLastRowNum()+1;
	         //System.out.println("Row Count: " + ORRowCount);
	          for(int i=1; i<ORRowCount; i++){
	        	  Cell = ORWSheet.getRow(i).getCell(0);
	              String CellData = Cell.getStringCellValue();
	              //System.out.println("CellData: " + CellData);
	              if(object.equalsIgnoreCase(CellData)){
	            	  Cell = ORWSheet.getRow(i).getCell(1);
	                  String ObjProperty = Cell.getStringCellValue();
	                  Log.info("The Property is: "+ObjProperty);
	                  return ObjProperty;
	              	}
	          }
	          
		} catch (Exception e) {
			Log.error("Unable to pick object property" + e.getMessage());
			 DriverScript.bResult = false;
		}
		return "Unable to pick object property";
	  }
		//click
		public static void Click(String object, String Varname,String ByProperty){
			
			try{
				Thread.sleep(10000);
				//driver.findElement(By.id("btn_start")).click();
				Log.info("Clicking on Webelement "+ object);
		 if (ByProperty.equalsIgnoreCase("name")){
				driver1.findElement(By.name(GetObjectProperty(object))).click();
				}
		 else if(ByProperty.equalsIgnoreCase("id")){
			driver1.findElement(By.id(GetObjectProperty(object))).click();	
			Thread.sleep(10000);
					}
				Log.info("clicked");
			 }catch(Exception e){
	 			Log.error("Not able to click --- " + e.getMessage());
	 			//DriverScript.bResult = false;
	         	}
		}
		
		 public static String GetReportPath(String object,String data,String ByProperty){
	          DateFormat df = new SimpleDateFormat("dd.MM.yy_HH.mm.ss");
	          Date dateobj = new Date();
	          String CurDate = df.format(dateobj);
	          String TempPath = Constants.Path_TestReport;
	          String[] Temp1 = TempPath.split("\\.");
	          String NewReportPath = Temp1[0]+"_"+CurDate+".html";
	          Log.info("Report is getting generated at: "+NewReportPath);
	          //System.out.println(NewReportPath);
	          return NewReportPath;
	    	}
		 
		 
		 
		
			public static void openApp(String object,String data,String ByProperty) throws MalformedURLException, InterruptedException
			{
					DesiredCapabilities capabilities = new DesiredCapabilities();
					capabilities.setCapability("deviceName", "Amitesh");
				capabilities.setCapability("platformVersion", "6.0.1");
				capabilities.setCapability("platformName", "Android");				
				capabilities.setCapability("appPackage", "com.thefloow.flo");
	     		capabilities.setCapability("appActivity", "com.thefloow.flo.activity.LauncherActivity");
				//capabilities.setCapability("noReset", "true");
	     		driver1 = new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
     		Thread.sleep(10000);
	  }
			
			
			public static void ImplicitWait(String object,String data,String ByProperty)
			{
				
				driver1.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
			}
			
			public static void CaptureDuration (String object, String Varname,String ByProperty) throws Exception{
				
			
						
				try{
					Thread.sleep(500);
					if (ByProperty.equalsIgnoreCase("name")){
						Constants.duration=driver1.findElement(By.name(GetObjectProperty(object))).getText();
						}
				 else if(ByProperty.equalsIgnoreCase("id")){
					 Constants.duration=driver1.findElement(By.id(GetObjectProperty(object))).getText();	
					 System.out.println(Constants.duration);
				 }
				}
				catch(Exception e){
					 Log.error("Unable to capture duration --- " + e.getMessage());
					 DriverScript.bResult = false;	
		         	}
				}
			
			public static void CaptureDistance (String object, String Varname,String ByProperty) throws Exception{
				
				
				
				try{
					Thread.sleep(500);
					if (ByProperty.equalsIgnoreCase("name")){
						Constants.distance=driver1.findElement(By.name(GetObjectProperty(object))).getText();
						}
				 else if(ByProperty.equalsIgnoreCase("id")){
					 Constants.distance=driver1.findElement(By.id(GetObjectProperty(object))).getText();
					 System.out.println(Constants.distance);
				
				 }
				}
				catch(Exception e){
					 Log.error("Unable to capture distance --- " + e.getMessage());
					 DriverScript.bResult = false;	
		         	}
				}
public static void back (String object, String Varname,String ByProperty) throws Exception{
				
				
				
				try{
					Thread.sleep(500);
					driver1.pressKeyCode(AndroidKeyCode.BACK);
					Thread.sleep(1000);
				}
				catch(Exception e){
					 Log.error("Unable to go back --- " + e.getMessage());
					 DriverScript.bResult = false;	
		         	}
				}
public static void captureScore (String object, String Varname,String ByProperty) throws Exception{
	
	
	
	try{
		Thread.sleep(500);
		
		
		//android.widget.TextView
		List<MobileElement> date = driver1.findElements(By.className("android.widget.TextView"));
		int oSize = date.size();
	//	System.out.println(oSize);
		for(int i=0 ; i<oSize ; i++)
		{
			String sValue = date.get(i).getText();
			
			//System.out.println(sValue);
		//	System.out.println(Varname);
		
				if (sValue.equalsIgnoreCase(Varname))
				{
					
					System.out.println(date.get(i).getText());
					Constants.Jdate=date.get(i).getText();
					i++;
					System.out.println(date.get(i).getText());
					Constants.Jtime=date.get(i).getText();
					i++;
					System.out.println(date.get(i).getText());
					Constants.Jdistance=date.get(i).getText();
					i++;
					System.out.println(date.get(i).getText());
					i++;
					System.out.println(date.get(i).getText());
					Constants.Jduration=date.get(i).getText();
					i++;
					System.out.println(date.get(i).getText());
					i++;
				Constants.score=date.get(i).getText();
				System.out.println(Constants.score);
				break;
				}
			
			}

		}
		
	catch(Exception e){
		 Log.error("Unable to go capture score --- " + e.getMessage());
		 DriverScript.bResult = false;	
     	}
	}
public static void Wait(String object,String data,String ByProperty) throws InterruptedException
{
	
	driver1.wait(10000);
}
public static void CaptureText(String object,String data,String ByProperty) throws InterruptedException
{
	Thread.sleep(10000);
	Constants.score1=driver1.findElement(By.id(GetObjectProperty(object))).getText();
}

public static void VerifyJourney (String object, String Varname,String ByProperty) throws Exception{
	

			
	try{
		Thread.sleep(500);
		if (Varname.equalsIgnoreCase(driver1.findElement(By.id("com.thefloow.flo:id/text_view_start_date")).getText()))
		
		{
			String Jdur=driver1.findElement(By.id("com.thefloow.flo:id/text_view_duration")).getText();
			String Jscore=driver1.findElement(By.id("com.thefloow.flo:id/text_view_score")).getText();
			String Jdis=driver1.findElement(By.id("com.thefloow.flo:id/text_view_distance")).getText();
			if (Jdur.equalsIgnoreCase(Constants.Jduration) && Jscore.equalsIgnoreCase(Constants.score) &&Jdis.equalsIgnoreCase(Constants.Jdistance))
			{
				System.out.println(Varname+"Journey Details are Verified and passed");
				 Log.info("Journey Details are Verified and passed");
			}
		 else
	      {
		 System.out.println(Varname+"Journey Details are mismatching and failed");
		 Log.info("Journey Details are mismatching and failed");
	      }
			
	}
	}
	catch(Exception e){
		 Log.error("Unable to verify journey details --- " + e.getMessage());
		 DriverScript.bResult = false;	
     	}
	}
public static void SelectJourney(String object, String Varname,String ByProperty){
	
	try{
		List<MobileElement> date = driver1.findElements(By.className("android.widget.TextView"));
		int oSize = date.size();
	//	System.out.println(oSize);
		for(int i=0 ; i<oSize ; i++)
		{
			String sValue = date.get(i).getText();
			
			//System.out.println(sValue);
		//	System.out.println(Varname);
		
				if (sValue.equalsIgnoreCase(Varname))
				{
					
					System.out.println(Constants.Jtime);
					i++;
					System.out.println(date.get(i).getText());
					if(Constants.Jtime.equalsIgnoreCase(date.get(i).getText()))
					{
					System.out.println(date.get(i).getText());
				    date.get(i).tap(1, 2);
				   
				    Log.info("clicked");
				  
					}
					
					else
					{
						Log.info("Unable to click on Journey");
					}
					
				}
			}
	
	 }
	catch(Exception e){
			Log.error("Not able to click --- " + e.getMessage());
		//	DriverScript.bResult = false;
     	}
}
public static void VerifyScores(String object,String data,String ByProperty) throws InterruptedException
{
	Thread.sleep(10000);
	String scores=driver1.findElement(By.id(GetObjectProperty(object))).getText();
	System.out.println(Constants.score1);
	System.out.println(scores);
	if(Constants.score1.equalsIgnoreCase(scores))
	{
		System.out.println("Scores are matching and Verfied");
	}
	else
	{
		System.out.println("Scores are not matching ");
	}
}


		}


